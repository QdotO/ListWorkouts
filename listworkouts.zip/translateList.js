// translateList.js

module.exports = (dbResponseList) => {
    return dbResponseList;
} 