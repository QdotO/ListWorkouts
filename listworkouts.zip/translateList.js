// translateList.js

module.exports = (dbResponseList) => {
    console.log("Translating this: ", dbResponseList);
    return dbResponseList;
} 